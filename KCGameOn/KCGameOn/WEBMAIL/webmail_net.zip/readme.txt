For installation instructions, open /webmail/adminpanel/docs/index.htm file and then click "Installation Instructions" in the contents.

If you'd like to upgrade existing product installation rather than installing it from scratch, check the instructions at: http://www.afterlogic.com/support/webmail-pro-net-upgrading-instructions
